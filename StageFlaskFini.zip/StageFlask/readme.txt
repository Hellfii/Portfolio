Projet Portfolio dans /venv/Scripts/HelloWorld.py

script flask est HelloWorld.py, le dossier script devrait contenir les dossiers templates et static.